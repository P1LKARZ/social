package com.example.social

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val twitter: ImageView = findViewById(R.id.imageView)
        val fb: ImageView=findViewById(R.id.imageView2)
        val ig: ImageView=findViewById(R.id.imageView3)


        twitter.setOnClickListener {
            val twitter = "https://twitter.com"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(twitter))
            startActivity(intent)
        }
        fb.setOnClickListener {
            val twitter = "https://www.facebook.com"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(twitter))
            startActivity(intent)
        }
        ig.setOnClickListener {
            val twitter = "https://www.instagram.com"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(twitter))
            startActivity(intent)
        }
    }
}
